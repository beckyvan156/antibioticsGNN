import pandas as pd
import io
import torch
import numpy as np
import os
import torch.nn as nn
import torch.nn.functional as F
import csv
import torch.nn.init as init
from torch_geometric.nn import GCNConv, global_mean_pool
from torch.nn import Linear
from torch_geometric.data import Data
from torch_geometric.utils import subgraph
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

import matplotlib.pyplot as plt

from torchsummary import summary
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RandomizedSearchCV


""" Import data"""

drug = pd.read_csv('C:/Users/becky/OneDrive/Desktop/2023 summer intern/Data/purified_data/drug.csv')
drug=drug.drop(drug.columns[0], axis=1)

edge=pd.read_csv('C:/Users/becky/OneDrive/Desktop/2023 summer intern/Data/purified_data/edge.csv')
edge=edge.drop(edge.columns[0], axis=1)

node=pd.read_csv('C:/Users/becky/OneDrive/Desktop/2023 summer intern/Data/purified_data/node.csv')

#phenotype=pd.read_csv('C:/Users/becky/OneDrive/Desktop/2023 summer intern/Data/purified_data/phenotype.csv')

phenotype=pd.read_csv('C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\Data\\purified_data\\antibiogram_phenotype.csv')



""" transform phenotype values to 0/1 """

# Replace 'resistant' with 1 and 'susceptible' with 0
phenotype = phenotype.replace({'resistant': 1, 'susceptible': 0})


""" Extract certain bacteria and antibiotics"""

"get list of combinations of unique bacterial and antibiotics"

# Create a DataFrame with unique combinations of 'bacteria' and 'antibiotics'
unique_combinations = phenotype.drop_duplicates(subset=['bacteria', 'antibiotics'])

# Randomly sample 
random_sample = unique_combinations.sample(n=93, random_state=1) # 'random_state' ensures reproducibility



# List of bacterial and antibiotics to include
include_bacteria = random_sample['bacteria']
include_antibiotics =  random_sample['antibiotics']

# Boolean masks for bacterial and antibiotics
mask_bacterial = phenotype['bacteria'].isin(include_bacteria)
mask_antibiotics = phenotype['antibiotics'].isin(include_antibiotics)

# Applying the masks to the dataframe
phenotype = phenotype[mask_bacterial & mask_antibiotics]


drug=drug[drug.index.isin(phenotype.index)]

node = node.rename(columns={node.columns[0]: 'sample_id'})
node=node[node['sample_id'].isin(phenotype['sample_id'])]


edge=edge[edge.index.isin(node.index)]
sample_ids=node['sample_id']
str_sample_ids = [str(i) for i in sample_ids]
edge=edge[str_sample_ids]



""" Get node names, node & drug combinations """

node_name=node[node.columns[0]]

node=node.drop(node.columns[0], axis=1)

node_drug_combination=drug[drug.columns[0]]

drug=drug.drop(drug.columns[0], axis=1)


" remove columns in node that are all 0"
node = node.loc[:, (node != 0).any(axis=0)]




"""**Transform Dataframe to Tensors**"""
phenotype=phenotype.iloc[:,-1]
# Convert the DataFrame to a numpy array
numpy_array = phenotype.values
# Convert the numpy array to a PyTorch Tensor
phenotype_tensor = torch.from_numpy(numpy_array)
print(phenotype_tensor)



# Convert the DataFrame to a numpy array
numpy_array = drug.values
# Convert the numpy array to a PyTorch Tensor
drug_tensor = torch.from_numpy(numpy_array)
print(drug_tensor)
drug_tensor =drug_tensor.float()



# Convert the DataFrame to a numpy array
numpy_array = edge.values
# Convert the numpy array to a PyTorch Tensor
edge_tensor = torch.from_numpy(numpy_array)
edge_tensor = edge_tensor.float()
print(edge_tensor)



# Convert the DataFrame to a numpy array
numpy_array = node.values
# Convert the numpy array to a PyTorch Tensor
node_tensor = torch.from_numpy(numpy_array)
print(node_tensor)
node_tensor = node_tensor.float()




"""**Transform distance matrix to edge index**"""

# Mask for the upper triangular part, excluding diagonal
mask = torch.triu(torch.ones_like(edge_tensor), diagonal=1)

# Extract the upper triangular elements
upper_triangular = edge_tensor * mask

# Get the indices of non-zero elements
indices = torch.nonzero(upper_triangular, as_tuple=True)

# Count the non-zero elements
count = torch.nonzero(upper_triangular).size(0)
print(count)

# Create the edge_index tensor
edge_index = torch.stack(indices, dim=0)

print(edge_index)
print(edge_index.shape)
print(edge_index.max().item())



""" **Sampling Graph Data to Training and Testing Datasets**"""

# Initialize the graph
# using the long() method
edge_long = edge_index.long()
data = Data(x=node_tensor, edge_index=edge_long)
print(data)


# Assuming 'data' is your full graph

# Randomly sample 266 (80%) nodes as training data
train_node_idx = torch.randperm(node_tensor.shape[0])[:round(node_tensor.shape[0]*0.8)]
print(train_node_idx.max().item())


# Extract subgraph
train_sub_node_features = data.x[train_node_idx]
train_sub_edge_index, _ = subgraph(train_node_idx, data.edge_index, relabel_nodes=False)




# Generate the array
array = torch.arange(0, node_tensor.shape[0])


# determine test data node idx
test_node_idx = array[np.isin(array, train_node_idx, invert=True)]


# use this boolean mask to select the desired elements from the data
test_sub_node_features = data.x[test_node_idx]
test_sub_edge_index, _ = subgraph(test_node_idx, data.edge_index, relabel_nodes=False)



node_name=torch.tensor(node_name.values)
train_node_name=node_name[train_node_idx]

test_node_name=node_name[test_node_idx]




""" ** Subtract training and testing datasets for Drug, Phenotype data ** """

# Convert to lists for easy comparison
node_drug_combination_list = node_drug_combination.tolist()
train_node_name_list = train_node_name.tolist()

# Use list comprehension to find indices in A that match names in B
train_drug_indices = [idx for idx, name in enumerate(node_drug_combination_list) if name in train_node_name_list]
train_drug_indices=torch.tensor(train_drug_indices)


# Convert to lists for easy comparison
test_node_name_list = test_node_name.tolist()

# Use list comprehension to find indices in A that match names in B
test_drug_indices = [idx for idx, name in enumerate(node_drug_combination_list) if name in test_node_name_list]
test_drug_indices=torch.tensor(test_drug_indices)

train_drug_tensor=drug_tensor[train_drug_indices]
test_drug_tensor=drug_tensor[test_drug_indices]


train_phenotype_tensor=phenotype_tensor[train_drug_indices]
test_phenotype_tensor=phenotype_tensor[test_drug_indices]






train_data = Data(x=train_sub_node_features, edge_index=train_sub_edge_index,
                  y=train_phenotype_tensor,condition=train_drug_tensor,
                  index=train_node_idx,node_name=train_node_name_list)




test_data = Data(x=test_sub_node_features, edge_index=test_sub_edge_index,
                 y=test_phenotype_tensor,condition=test_drug_tensor,
                 index=test_node_idx,node_name=test_node_name_list)

















""" ** Wrap training data (from Graph) to DataLoader ** """

def get_y_indices_for_x(x_index_range):
    node_name_i=node_name[x_index_range]
    node_name_i=node_name_i.tolist()
    drug_indices = [idx for idx, name in enumerate(node_drug_combination_list) if name in node_name_i]
    drug_indices=torch.tensor(drug_indices)  
    return drug_indices

# add edge to isolated nodes connecting to themselves, allowing you to utilize the subgraph() function without errors.#
def add_self_loops(edge_index, num_nodes):
    # Generate self-loops
    self_loops = torch.arange(num_nodes).unsqueeze(0).repeat(2, 1)
    
    # Concatenate edge_index with self-loops
    edge_index_with_loops = torch.cat([edge_index, self_loops], dim=1)
    
    return edge_index_with_loops

# Assuming you have edge_index and num_nodes (total number of nodes in the graph)
edge_index_with_loops = add_self_loops(edge_index, node_tensor.shape[0])





def split_graph_into_subgraphs(data, num_subgraphs=10):
    subgraphs = []
    
    # Randomly permute the indices
    total_nodes = data.x.shape[0]
    permuted_indices = torch.randperm(total_nodes)
    
    nodes_per_subgraph = total_nodes // num_subgraphs
    
    for i in range(num_subgraphs):
        start_idx = i * nodes_per_subgraph
        end_idx = (i + 1) * nodes_per_subgraph
        
        # Use the permuted indices to get the actual indices for x and y
        current_indices = permuted_indices[start_idx:end_idx]
        
        node_index_i=data.index[current_indices]
        node_name_i= node_name[node_index_i]
        node_name_i_list = node_name_i.tolist()
        
        sub_node=node_tensor[node_index_i]
        sub_edge_index, _ = subgraph(node_index_i,edge_index_with_loops, relabel_nodes=True)

        drug_indices=get_y_indices_for_x(node_index_i)
        drug_tensor_i=drug_tensor[drug_indices]
        phenotype_i=phenotype_tensor[drug_indices]
        
        
        sub_data = Data(x=sub_node, edge_index=sub_edge_index,
                          y=phenotype_i,condition=drug_tensor_i, index=node_index_i, node_name=node_name_i_list)
        subgraphs.append(sub_data)
    
    return subgraphs




# Create subgraphs
torch.manual_seed(123)
subgraphs= split_graph_into_subgraphs(train_data, num_subgraphs=32)

for i, subgraph in enumerate(subgraphs):
    max_index_subgraph = subgraph.index.max()
    print(f"Maximum index in subgraph {i}: {max_index_subgraph}")


for subgraph in subgraphs:
    # Assuming subgraph.index contains the original indices for each node in this subgraph
    # Add these indices as a node feature (you might need to unsqueeze to add a feature dimension)
    subgraph.x = torch.cat((subgraph.x, subgraph.index.unsqueeze(1)), dim=1)


# Now use the DataLoader
from torch_geometric.data import DataLoader
train_loader = DataLoader(subgraphs, batch_size=6, shuffle=True)




batch = next(iter(train_loader))
single_data_instance = batch[5]
print(single_data_instance.index)
# print(single_data_instance.edge_index)




"relabel edge index for complete training and testing data"
from torch_geometric.utils import subgraph

train_data.edge_index, _ = subgraph(train_node_idx, data.edge_index, relabel_nodes=True)               
print(train_data.edge_index)


test_data.edge_index, _ = subgraph(test_node_idx, data.edge_index, relabel_nodes=True)               
print(test_data.edge_index)



""" **************************    Write FiLM   ***********************************  """


""" 1). Build Linear Layers to Get Drug Embeddings for training and test data"""


""" 2). Build FiLM layers """
node_drug_combination_list_str = [str(item) for item in node_drug_combination_list]


class FiLMedGNN(torch.nn.Module):
    def __init__(self, hidden_dim, dropout=0.3, node_dim=14615,condition_dim=29):
        super(FiLMedGNN, self).__init__()
        self.hidden_dim=hidden_dim
        # self.hidden_dim2=hidden_dim2
        self.condition_dim=condition_dim
        self.node_dim=node_dim
        
        # simpliest model: linear layer of node feature
        self.out_proj2= Linear(node_dim+condition_dim, 2)
        
        
        # simple model: 1 conv layer
        self.conv2 = GCNConv(self.node_dim+condition_dim, self.hidden_dim)

        
        # FilM model: 1 conv layer + 1 film layer
        self.conv1 = GCNConv(self.node_dim, self.hidden_dim)
        #self.conv2 = GCNConv(self.hidden_dim, self.hidden_dim2)
        # self.bn1 = nn.BatchNorm1d(self.hidden_dim)
        
        # self.conv2 = GCNConv(self.hidden_dim1, self.hidden_dim2)
        # #self.conv2 = GCNConv(self.hidden_dim, self.hidden_dim2)
        # self.bn2 = nn.BatchNorm1d(self.hidden_dim2)

  
        # Global FiLM Parameters
        self.linear_gamma = Linear(self.condition_dim, self.hidden_dim)
        self.linear_beta = Linear(self.condition_dim, self.hidden_dim)

        # This will be used for condition-level predictions
        self.out_proj = Linear(hidden_dim, 2)

        # add dropout to prevent overfitting
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, data):
        x, edge_index, condition, index = data.x, data.edge_index,  data.condition, data.index
        

        # # Generate FiLM parameters
        # gamma = self.linear_gamma(condition)
        # beta = self.linear_beta(condition)

        # # Apply GNN layers with FiLM
        # x = self.conv1(x, edge_index)
        # # x = self.bn1(x)
        # x = F.leaky_relu(x, negative_slope=0.1)
        
        # # x = self.conv2(x, edge_index)
        # # x = self.bn2(x)
        # # x = F.leaky_relu(x, negative_slope=0.1)
        
        # Expand node feature matrix to match the dimension of y
        node_names_tensor=node_name[index]
        node_names_tensor_str = [str(node_name.item()) for node_name in node_names_tensor]
        extracted_info = []
        for node_name_str in node_names_tensor_str:
            # Extract strings from node_drug_combination_list_str that contain node_name_str
            matches = [entry for entry in node_drug_combination_list_str if node_name_str in entry]
            extracted_info.extend(matches)  # Add the found strings to the extracted_info list
            
        a=data.node_name
        
        if isinstance(a[0], list):  # Check if the first element is a list
            expanded_a = [node_name for sublist in a for node_name in sublist]
        else:
            # If 'a' is a list of individual elements (each of size 1)
            expanded_a = a[:]  # or a.copy()
    
               
        data_node_name_str = [str(name) for name in expanded_a]
        
        name_to_index = {name: i for i, name in enumerate(data_node_name_str)}
        extracted_indices = [name_to_index[name] for name in extracted_info if name in name_to_index]
        extracted_indices_tensor = torch.tensor(extracted_indices)
        expanded_x = x[extracted_indices_tensor]
        
        
        
        # simpliest model: linear layer of node feature w/o FiLM of node feature
        # combined_tensor = torch.cat((expanded_x, condition), dim=1)
        # out= self.out_proj2(combined_tensor)
        
        
        
        # simple conv model: 1 conv layer
        combined_tensor = torch.cat((expanded_x, condition), dim=1)
        out= self.conv2(combined_tensor,edge_index)
        out = self.dropout(out)
        out = self.out_proj(out)
    
    
    
    
        # # FiLM
        # x =  expanded_x * gamma + beta



        # x = F.leaky_relu(x, negative_slope=0.1)
        # x = self.dropout(x)
    

        # # final prediction
        # out = self.out_proj(x)

        # apply softmax to the output
        out =F.log_softmax(out, dim=1)



        return out





vals = { 'hidden_dim':64,
         'dropout':0.3, 'node_dim':train_data.x.shape[1], 'condition_dim':29}

model = FiLMedGNN(**vals)






"""  *****************************   Train the model   ****************************** """ 

optimizer = torch.optim.Adam(model.parameters(), lr=0.001)


""" 1). Define traing and test functions """

def train():
    
    model.train()
    total_loss = 0.0

    # Iterate over batches
    for data in train_loader:
        optimizer.zero_grad()
        data.index=data.x[:, -1] # get original node index
        data.index = data.index.long()
        data.x = data.x[:, :-1]  # remove last column as original node index
        output = model(data)
        loss = F.nll_loss(output, data.y)
        loss.backward()
        # Accumulate the total loss
        total_loss += loss.item()
        optimizer.step()
    return total_loss


def test(input_data):

    model.eval()
    output = model(input_data)
    pred = output.max(dim=1)[1]
    correct = pred.eq(input_data.y).sum().item()
    return correct / len(input_data.y)


# Function to save test data predictions
folder_path='C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\repo'
def save_predictions(input_data, epoch):
    model.eval()

    # Store probabilities here
    all_probs = []
    
    # Make sure to disable gradients for evaluation
    with torch.no_grad():
        output = model(input_data)
        
        # Apply exponential to log-softmax output to get probabilities
        probabilities = torch.exp(output)
        
        # Add probabilities to list (detach tensor and convert them to list)
        all_probs.extend(probabilities.cpu().numpy().tolist())
        
    # Convert the list to a DataFrame
    df = pd.DataFrame(all_probs, columns=[f'Class_{i}' for i in range(output.size(1))])
    
    # Save the DataFrame to a CSV file
    df.to_csv(f'{folder_path}\\epoch_{epoch}_probabilities.csv', index=False)



""" 3). Train the model  """

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

# create lists to save train ACC and test ACC for each epoch
train_accuracies = []
test_accuracies = []



for epoch in range(101):
    loss = train()

    train_acc = test(input_data=train_data)
    train_accuracies.append(train_acc)

    test_acc = test(input_data=test_data)
    test_accuracies.append(test_acc)
    print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, 'f'Train Acc: {train_acc:.4f}, Test Acc: {test_acc:.4f}')
    
    # Save test data predictions at epoch 50 and 80
    if epoch == 0 or epoch == 100:
        save_predictions(input_data=test_data, epoch=epoch)
        
        # Print gradients
        print(f"\nGradients at epoch {epoch}:")
        for name, param in model.named_parameters():
            if param.grad is not None:
                print(f"{name}: {param.grad.norm().item()}")
        print("\n")
        
    
""" Visualize train and test ACC """
plt.figure(figsize=(12, 6))
plt.plot(train_accuracies, label='Train Accuracy')
plt.plot(test_accuracies, label='Test Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.title('Training and Testing Accuracy across Epochs: rate=0.001')
plt.legend()
plt.grid(True)
plt.show() 



################################################################################################


""" Use training data with random forest """

# Expand train node feature matrix to match the dimension of y
node_names_tensor=node_name[train_data.index]
node_names_tensor_str = [str(node_name.item()) for node_name in node_names_tensor]
extracted_info = []
for node_name_str in node_names_tensor_str:
    # Extract strings from node_drug_combination_list_str that contain node_name_str
    matches = [entry for entry in node_drug_combination_list_str if node_name_str in entry]
    extracted_info.extend(matches)  # Add the found strings to the extracted_info list
    
a=train_data.node_name

if isinstance(a[0], list):  # Check if the first element is a list
    expanded_a = [node_name for sublist in a for node_name in sublist]
else:
    # If 'a' is a list of individual elements (each of size 1)
    expanded_a = a[:]  # or a.copy()

       
data_node_name_str = [str(name) for name in expanded_a]

name_to_index = {name: i for i, name in enumerate(data_node_name_str)}
extracted_indices = [name_to_index[name] for name in extracted_info if name in name_to_index]
extracted_indices_tensor = torch.tensor(extracted_indices)
expanded_train = train_data.x[extracted_indices_tensor]

expanded_train = torch.cat((expanded_train, train_data.condition), dim=1)

# Expand test node feature matrix to match the dimension of y
node_names_tensor=node_name[test_data.index]
node_names_tensor_str = [str(node_name.item()) for node_name in node_names_tensor]
extracted_info = []
for node_name_str in node_names_tensor_str:
    # Extract strings from node_drug_combination_list_str that contain node_name_str
    matches = [entry for entry in node_drug_combination_list_str if node_name_str in entry]
    extracted_info.extend(matches)  # Add the found strings to the extracted_info list
    
a=test_data.node_name

if isinstance(a[0], list):  # Check if the first element is a list
    expanded_a = [node_name for sublist in a for node_name in sublist]
else:
    # If 'a' is a list of individual elements (each of size 1)
    expanded_a = a[:]  # or a.copy()

       
data_node_name_str = [str(name) for name in expanded_a]

name_to_index = {name: i for i, name in enumerate(data_node_name_str)}
extracted_indices = [name_to_index[name] for name in extracted_info if name in name_to_index]
extracted_indices_tensor = torch.tensor(extracted_indices)
expanded_test = test_data.x[extracted_indices_tensor]

expanded_test= torch.cat((expanded_test, test_data.condition), dim=1)




## train the model, and calculate accuracy ##
rf_model = RandomForestClassifier()
cv_scores = cross_val_score(rf_model, expanded_train, train_data.y, cv=5)  # 5-fold cross-validation

# Print results
print(f"CV Scores: {cv_scores}")
print(f"Average CV Score: {np.mean(cv_scores)}")
rf_model.fit(expanded_train, train_data.y)

test_predictions = rf_model.predict(expanded_test)

accuracy = accuracy_score(test_data.y, test_predictions)
print(f"Test Accuracy: {accuracy}")




""" Add CV"""

# Define the parameter grid to search
param_dist = {
    'n_estimators': [100, 200, 300, 400, 500],
    'max_depth': [None, 10, 20, 30, 40],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
    # You can add more parameters here
}

# Initialize the base model
rf = RandomForestClassifier()

# Perform randomized search with cross-validation
random_search = RandomizedSearchCV(estimator=rf, param_distributions=param_dist, 
                                   n_iter=50, cv=3, verbose=2, random_state=42, n_jobs=4)


# Fit the random search model
random_search.fit(expanded_train, train_data.y)

# Best hyperparameters
best_hyperparameters = random_search.best_params_
print("Best Hyperparameters:", best_hyperparameters)

# Fit the best model on the entire training dataset
best_rf_model = RandomForestClassifier(**best_hyperparameters)
best_rf_model.fit(expanded_train, train_data.y)


test_predictions = best_rf_model.predict(expanded_test)

accuracy = accuracy_score(test_data.y, test_predictions)
print(f"Test Accuracy: {accuracy}")




## output results to csv ##

phenotype=pd.read_csv('C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\Data\\purified_data\\antibiogram_phenotype.csv')
phenotype = phenotype.replace({'resistant': 1, 'susceptible': 0})
index_numpy = test_drug_indices.numpy()
test_phenotype = phenotype.loc[index_numpy]

test_phenotype['RandomForestPrediction'] = test_predictions


gnn_prediction=pd.read_csv('C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\repo\\epoch_100_probabilities.csv')
gnn_prediction['GNNPrediction'] = np.where(gnn_prediction['Class_0'] > gnn_prediction['Class_1'], 0, 1)


test_phenotype['GNNPrediction'] = gnn_prediction['GNNPrediction']


test_phenotype.to_csv(f'{folder_path}\\test_data_prediction.csv', index=False)




## save train and test data ##
path_train = 'C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\repo\\debug\\clean data for model training\\train_data.pth'
path_test = 'C:\\Users\\becky\\OneDrive\\Desktop\\2023 summer intern\\repo\\debug\\clean data for model training\\test_data.pth'

# Save the data
torch.save(train_data, path_train)
torch.save(test_data, path_test)








